from .src.figures import (
    Circle,
    Rectangle,
    Triangle,
)
from .src.figure_factory import (
    FigureFactory
)
from .src.figure import (
    Figure
)
